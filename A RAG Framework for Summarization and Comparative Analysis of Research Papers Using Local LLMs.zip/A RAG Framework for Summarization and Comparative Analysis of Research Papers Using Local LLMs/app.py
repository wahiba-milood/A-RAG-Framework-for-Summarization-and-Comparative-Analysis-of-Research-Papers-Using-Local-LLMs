import fitz  # مكتبة PyMuPDF لقراءة الـ PDF مجاناً
from langchain_community.llms import Ollama  # لاستدعاء النموذج المحلي المجاني
import os

# دالة بسيطة لقراءة ملف البحث واستخراج النص منه محلياً
def extract_text_from_pdf(pdf_path):
    try:
        doc = fitz.open(pdf_path)
        text = ""
        for page in doc:
            text += page.get_text()
        return text
    except Exception as e:
        return f"خطأ في قراءة الملف: {e}"

print("="*60)
print("📚 نظام التلخيص والمقارنة التلقائي للأبحاث (نسخة موجه الأوامر)")
print("مشروع: وهيبة ميلود & حنان | إشراف: د. أحمد العرضاوي")
print("="*60)
print("\nجاري فحص المجلد الحالي تلقائياً للبحث عن ملفات الـ PDF...")

# 1. قراءة المجلد وتصفية الملفات لتكون بصيغة .pdf فقط ومهما كانت أسماؤها
current_folder = os.getcwd()
pdf_files = [f for f in os.listdir(current_folder) if f.lower().endswith('.pdf')]

if len(pdf_files) == 0:
    print("\n[!] تنبيه: لم يتم العثور على أي ملفات PDF في المجلد الحالي!")
    print(f"يرجى وضع ملفات الأبحاث العلمية (صيغة PDF فقط) داخل هذا المسار أولاً: {current_folder}")
else:
    # نحدد كحد أقصى أول 5 ملفات PDF تم العثور عليها
    pdf_files_to_analyze = pdf_files[:5]
    
    print(f"\n[+] تم العثور على {len(pdf_files_to_analyze)} ملفات PDF وسيتم تحليلها ومقارنتها فوراً:")
    for idx, name in enumerate(pdf_files_to_analyze, 1):
        print(f"  [{idx}] {name}")
    
    # 2. استخراج النصوص تلقائياً من ملفات الـ PDF المكتشفة
    print("\nجاري استخراج النصوص من الأبحاث محلياً...")
    papers_texts = []
    for file_name in pdf_files_to_analyze:
        papers_texts.append(extract_text_from_pdf(file_name))
        
    # 3. استدعاء نموذج Llama 3 المحلي
    llm = Ollama(model="llama3")

    # 4. بناء الأمر الذكي (Prompt) ديناميكياً بحسب الأسماء الفعلية والعدد
    papers_prompt_part = ""
    for idx, (name, text) in enumerate(zip(pdf_files_to_analyze, papers_texts), 1):
        papers_prompt_part += f"\nResearch Paper {idx} (Actual Name: {name}):\n{text[:2500]}\n"

    prompt = f"""
    You are an expert academic reviewer. Based ONLY on the extracted texts of the research papers provided below, complete the following:
    Generate a comprehensive automated comparative matrix that summarizes and compares the papers regarding (Methodology, Database/Dataset, Key Results, and Research Gaps/Limitations) in a single, well-structured Markdown table/matrix to facilitate scientific review.
    
    Please use the actual file names as the column or row headers in your matrix. You can write the table headers and analysis in English or Arabic as appropriate for an academic report.

    Number of papers to compare: {len(pdf_files_to_analyze)}
    {papers_prompt_part}
    """

    print("\n[🚀] جاري إرسال النصوص لنموذج Llama 3 للتحليل الدلالي والمقارنة...")
    print("[⏳] جاري توليد الجدول والمصفوفة محلياً بالكامل (يرجى الانتظار دقيقتين)...")
    
    # 5. تشغيل النظام واستقبال النتيجة
    response = llm.invoke(prompt)

    # عرض النتيجة النهائية للمصفوفة على الشاشة السوداء
    print("\n" + "="*20 + " Comprehensive Comparative Matrix Result " + "="*20)
    print(response)
    print("="*80)